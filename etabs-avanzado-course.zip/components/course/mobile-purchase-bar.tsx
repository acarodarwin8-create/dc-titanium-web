import { course } from '@/lib/course-data'

export function MobilePurchaseBar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-background/95 backdrop-blur-xl lg:hidden">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3">
        <div className="flex flex-col">
          <span className="font-display text-lg font-bold text-foreground">
            ${course.price}
          </span>
          <span className="text-xs text-muted-foreground line-through">
            ${course.originalPrice}
          </span>
        </div>
        <button className="ml-auto flex-1 rounded-lg bg-primary py-3 font-display text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 active:scale-[0.99]">
          Comprar ahora
        </button>
      </div>
    </div>
  )
}
