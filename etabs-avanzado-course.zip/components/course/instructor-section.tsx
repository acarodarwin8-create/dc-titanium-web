import { Star, MessageSquare, Users, PlaySquare, BadgeCheck } from 'lucide-react'
import Image from 'next/image'
import { instructor } from '@/lib/course-data'

const stats = [
  { icon: Star, label: 'Calificación', value: instructor.stats.rating },
  { icon: MessageSquare, label: 'Reseñas', value: instructor.stats.reviews.toLocaleString('es') },
  { icon: Users, label: 'Estudiantes', value: instructor.stats.students.toLocaleString('es') },
  { icon: PlaySquare, label: 'Cursos', value: instructor.stats.courses },
]

export function InstructorSection() {
  return (
    <section>
      <h2 className="mb-2 font-display text-xl font-semibold tracking-tight md:text-2xl">
        Instructor
      </h2>
      <div className="rounded-xl border border-border bg-card p-6 md:p-8">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-start">
          <div className="relative size-28 shrink-0 overflow-hidden rounded-full ring-2 ring-primary/40">
            <Image
              src={instructor.avatar}
              alt={`Retrato de ${instructor.name}`}
              fill
              className="object-cover"
              sizes="112px"
            />
          </div>

          <div className="flex-1">
            <h3 className="flex items-center gap-2 font-display text-lg font-semibold text-foreground">
              {instructor.name}
              <BadgeCheck className="size-5 text-primary" />
            </h3>
            <p className="mt-1 text-sm text-primary">{instructor.role}</p>

            <dl className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {stats.map(({ icon: Icon, label, value }) => (
                <div key={label} className="rounded-lg border border-border/60 bg-secondary/40 p-3">
                  <dt className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Icon className="size-3.5 text-primary/70" />
                    {label}
                  </dt>
                  <dd className="mt-1 font-display text-lg font-semibold text-foreground">
                    {value}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </div>

        <p className="mt-6 text-sm leading-relaxed text-muted-foreground text-pretty">
          {instructor.bio}
        </p>

        <ul className="mt-5 flex flex-col gap-2.5">
          {instructor.credentials.map((c) => (
            <li key={c} className="flex items-start gap-2.5 text-sm text-muted-foreground">
              <BadgeCheck className="mt-0.5 size-4 shrink-0 text-primary/80" />
              {c}
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
