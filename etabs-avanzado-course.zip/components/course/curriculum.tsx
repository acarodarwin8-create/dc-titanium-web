'use client'

import { ChevronDown, PlayCircle, FileVideo } from 'lucide-react'
import { useState } from 'react'
import { curriculum, course } from '@/lib/course-data'

export function Curriculum() {
  const [open, setOpen] = useState<number[]>([0])
  const allOpen = open.length === curriculum.length

  function toggle(i: number) {
    setOpen((prev) =>
      prev.includes(i) ? prev.filter((x) => x !== i) : [...prev, i],
    )
  }

  return (
    <section>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <h2 className="font-display text-xl font-semibold tracking-tight md:text-2xl">
          Contenido del curso
        </h2>
        <button
          onClick={() => setOpen(allOpen ? [] : curriculum.map((_, i) => i))}
          className="text-sm font-medium text-primary underline-offset-4 transition-colors hover:underline"
        >
          {allOpen ? 'Contraer todo' : 'Expandir todo'}
        </button>
      </div>

      <p className="mb-4 text-sm text-muted-foreground">
        {curriculum.length} secciones · {course.totalLectures} clases ·{' '}
        {course.totalHours} h de duración total
      </p>

      <div className="overflow-hidden rounded-xl border border-border bg-card">
        {curriculum.map((section, i) => {
          const isOpen = open.includes(i)
          return (
            <div key={section.section} className="border-b border-border/60 last:border-b-0">
              <button
                onClick={() => toggle(i)}
                aria-expanded={isOpen}
                className="flex w-full items-center gap-3 px-5 py-4 text-left transition-colors hover:bg-accent/50"
              >
                <ChevronDown
                  className={`size-5 shrink-0 text-primary transition-transform duration-300 ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
                <span className="flex-1 font-display font-medium text-foreground">
                  {section.section}
                </span>
                <span className="hidden text-xs text-muted-foreground sm:block">
                  {section.lectures} clases · {section.duration}
                </span>
              </button>

              <div
                className={`grid transition-all duration-300 ease-out ${
                  isOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'
                }`}
              >
                <div className="overflow-hidden">
                  <ul className="border-t border-border/40 bg-background/40">
                    {section.items.map((item) => (
                      <li
                        key={item.title}
                        className="flex items-center gap-3 py-3 pl-12 pr-5 text-sm transition-colors hover:bg-accent/40"
                      >
                        {item.preview ? (
                          <PlayCircle className="size-4 shrink-0 text-primary" />
                        ) : (
                          <FileVideo className="size-4 shrink-0 text-muted-foreground" />
                        )}
                        <span className="flex-1 text-muted-foreground">
                          {item.title}
                        </span>
                        {item.preview && (
                          <span className="rounded bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                            Vista previa
                          </span>
                        )}
                        <span className="text-xs tabular-nums text-muted-foreground">
                          {item.duration}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}
