import { Check } from 'lucide-react'
import { highlights } from '@/lib/course-data'

export function WhatYouLearn() {
  return (
    <section className="rounded-xl border border-border bg-card p-6 md:p-8">
      <h2 className="font-display text-xl font-semibold tracking-tight md:text-2xl">
        Lo que aprenderás
      </h2>
      <ul className="mt-6 grid gap-x-8 gap-y-4 sm:grid-cols-2">
        {highlights.map((item) => (
          <li key={item} className="flex items-start gap-3">
            <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/15">
              <Check className="size-3 text-primary" strokeWidth={3} />
            </span>
            <span className="text-sm leading-relaxed text-muted-foreground">
              {item}
            </span>
          </li>
        ))}
      </ul>
    </section>
  )
}
