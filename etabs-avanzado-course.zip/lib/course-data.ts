export const course = {
  title: 'ETABS Avanzado: Pórticos SMF Sísmicos',
  subtitle:
    'Análisis y diseño sísmico de pórticos especiales resistentes a momento (SMF) según ASCE 7-22 y AISC 341, aplicado en modelos reales de ETABS.',
  badge: 'Certificación Profesional',
  rating: 4.9,
  ratingCount: 2148,
  students: 9740,
  lastUpdated: 'Agosto 2026',
  language: 'Español',
  level: 'Avanzado',
  totalHours: 22.5,
  totalLectures: 148,
  price: 189.99,
  originalPrice: 499.99,
  discountEndsIn: '2 días',
}

export const highlights = [
  'Modelar pórticos SMF de acero en ETABS con criterios sísmicos rigurosos.',
  'Aplicar el análisis modal espectral y el método de fuerza lateral equivalente.',
  'Diseñar conexiones precalificadas RBS y WUF-W según AISC 358.',
  'Verificar el criterio de columna fuerte - viga débil (SCWB).',
  'Calcular derivas de entrepiso y controlar efectos P-Delta.',
  'Interpretar la relación demanda/capacidad de cada elemento estructural.',
  'Ejecutar un análisis pushover no lineal y evaluar rótulas plásticas.',
  'Preparar memorias de cálculo listas para revisión profesional.',
]

export const curriculum = [
  {
    section: 'Fundamentos del diseño sísmico',
    lectures: 12,
    duration: '1h 48m',
    items: [
      { title: 'Introducción al comportamiento sísmico de pórticos SMF', duration: '11:24', preview: true },
      { title: 'Filosofía de diseño por capacidad', duration: '14:02' },
      { title: 'Sistemas resistentes a fuerzas sísmicas en ASCE 7-22', duration: '18:30' },
      { title: 'Factores R, Cd y Ω0 explicados', duration: '12:15', preview: true },
    ],
  },
  {
    section: 'Modelado del edificio en ETABS',
    lectures: 24,
    duration: '3h 52m',
    items: [
      { title: 'Configuración de grillas, niveles y materiales', duration: '16:44' },
      { title: 'Definición de secciones de acero y asignación', duration: '21:08' },
      { title: 'Diafragmas rígidos y modelado de losas', duration: '19:33' },
      { title: 'Cargas gravitacionales y combinaciones LRFD', duration: '17:52' },
    ],
  },
  {
    section: 'Análisis sísmico avanzado',
    lectures: 28,
    duration: '4h 40m',
    items: [
      { title: 'Análisis modal: masas participativas y periodos', duration: '22:10', preview: true },
      { title: 'Espectro de respuesta de diseño ASCE 7-22', duration: '20:47' },
      { title: 'Método de fuerza lateral equivalente vs. modal', duration: '18:19' },
      { title: 'Escalamiento de cortante basal y ajuste de resultados', duration: '24:05' },
    ],
  },
  {
    section: 'Diseño de conexiones precalificadas',
    lectures: 22,
    duration: '3h 28m',
    items: [
      { title: 'Conexión RBS (Reduced Beam Section) paso a paso', duration: '26:41' },
      { title: 'Conexión WUF-W soldada según AISC 358', duration: '23:15' },
      { title: 'Zona panel y placas de continuidad', duration: '19:58' },
      { title: 'Verificación de columna fuerte - viga débil', duration: '21:37' },
    ],
  },
  {
    section: 'Verificaciones de código y derivas',
    lectures: 20,
    duration: '2h 55m',
    items: [
      { title: 'Control de derivas de entrepiso', duration: '17:22' },
      { title: 'Efectos P-Delta y estabilidad', duration: '19:44' },
      { title: 'Relación demanda/capacidad de elementos', duration: '15:30' },
      { title: 'Irregularidades en planta y en altura', duration: '18:11' },
    ],
  },
  {
    section: 'Análisis no lineal y proyecto final',
    lectures: 42,
    duration: '5h 47m',
    items: [
      { title: 'Introducción al análisis pushover', duration: '25:18', preview: true },
      { title: 'Definición de rótulas plásticas', duration: '28:04' },
      { title: 'Curva de capacidad y punto de desempeño', duration: '23:49' },
      { title: 'Proyecto final: edificio de 8 niveles completo', duration: '41:12' },
    ],
  },
]

export const requirements = [
  'Conocimientos previos de análisis estructural estático.',
  'Familiaridad básica con la interfaz de ETABS (o haber tomado el curso intermedio).',
  'Nociones de diseño de acero según AISC 360.',
  'Una licencia de ETABS (versión de prueba compatible).',
]

export const instructor = {
  name: 'Ing. Rafael Mendoza, M.Sc., P.E.',
  role: 'Ingeniero Estructural Sísmico · 18 años de experiencia',
  bio: 'Rafael es ingeniero estructural licenciado (P.E.) especializado en diseño sísmico de edificios de acero y concreto. Ha liderado el diseño de más de 60 edificios de mediana y gran altura en zonas de alta sismicidad, y es instructor certificado de CSI en ETABS y SAP2000.',
  avatar: '/instructor.png',
  stats: {
    rating: 4.9,
    reviews: 8320,
    students: 41200,
    courses: 12,
  },
  credentials: [
    'M.Sc. en Ingeniería Estructural, universidad de investigación líder.',
    'Licencia Professional Engineer (P.E.) en diseño estructural.',
    'Miembro de AISC y del comité técnico de estructuras de acero.',
  ],
}

export const testimonials = [
  {
    name: 'Andrea Solís',
    role: 'Ingeniera de proyectos, firma de consultoría',
    rating: 5,
    text: 'El módulo de conexiones precalificadas cambió por completo mi forma de trabajar. Pasé de dudar de mis modelos a entregar memorias de cálculo con total confianza.',
  },
  {
    name: 'Diego Fuentes',
    role: 'Estudiante de maestría en estructuras',
    rating: 5,
    text: 'La explicación del análisis pushover es la más clara que he encontrado. Rafael conecta la teoría del código con lo que realmente pasa en ETABS.',
  },
  {
    name: 'María José Rivas',
    role: 'Ingeniera estructural senior',
    rating: 5,
    text: 'Vale cada centavo. El proyecto final del edificio de 8 niveles es prácticamente un caso real de oficina. Lo uso como referencia constante.',
  },
  {
    name: 'Carlos Anaya',
    role: 'Jefe de departamento estructural',
    rating: 5,
    text: 'Compré licencias para todo mi equipo junior. La sección de columna fuerte - viga débil por sí sola justifica la inversión.',
  },
]
