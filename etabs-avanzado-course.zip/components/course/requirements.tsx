import { requirements } from '@/lib/course-data'

export function Requirements() {
  return (
    <section>
      <h2 className="mb-5 font-display text-xl font-semibold tracking-tight md:text-2xl">
        Requisitos
      </h2>
      <ul className="flex flex-col gap-3">
        {requirements.map((req) => (
          <li key={req} className="flex items-start gap-3 text-sm leading-relaxed text-muted-foreground">
            <span className="mt-2 size-1.5 shrink-0 rounded-full bg-primary" />
            {req}
          </li>
        ))}
      </ul>
    </section>
  )
}
