import { Search, ChevronDown } from 'lucide-react'

export function TopNav() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-4 md:px-8">
        <a href="#" className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-md bg-primary font-display text-sm font-bold text-primary-foreground">
            E
          </span>
          <span className="font-display text-lg font-semibold tracking-tight">
            Estructura<span className="text-primary">Pro</span>
          </span>
        </a>

        <nav className="hidden items-center gap-1 text-sm text-muted-foreground lg:flex">
          <button className="flex items-center gap-1 rounded-md px-3 py-2 transition-colors hover:text-foreground">
            Cursos <ChevronDown className="size-3.5" />
          </button>
          <a href="#" className="rounded-md px-3 py-2 transition-colors hover:text-foreground">
            Rutas
          </a>
          <a href="#" className="rounded-md px-3 py-2 transition-colors hover:text-foreground">
            Empresas
          </a>
        </nav>

        <div className="ml-auto hidden max-w-md flex-1 items-center gap-2 rounded-full border border-border bg-secondary/60 px-4 py-2 md:flex">
          <Search className="size-4 text-muted-foreground" />
          <input
            type="search"
            placeholder="Buscar cursos de ingeniería..."
            className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
          />
        </div>

        <div className="ml-auto flex items-center gap-3 md:ml-0">
          <button className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground sm:block">
            Iniciar sesión
          </button>
          <button className="rounded-full border border-primary/40 bg-primary/10 px-4 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary/20">
            Registrarse
          </button>
        </div>
      </div>
    </header>
  )
}
