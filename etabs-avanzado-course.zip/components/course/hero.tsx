import { Star, Users, Globe, Clock, BarChart3, ChevronRight } from 'lucide-react'
import { course } from '@/lib/course-data'

function Stars({ rating }: { rating: number }) {
  return (
    <span className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className="size-4 text-primary"
          fill={i < Math.round(rating) ? 'currentColor' : 'none'}
          strokeWidth={1.5}
        />
      ))}
    </span>
  )
}

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-border/60">
      {/* ambient gold glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 right-0 size-[520px] rounded-full bg-primary/10 blur-[120px]"
      />
      <div className="relative mx-auto max-w-7xl px-4 py-12 md:px-8 md:py-16 lg:pr-[420px]">
        <nav className="mb-6 flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
          <a href="#" className="transition-colors hover:text-primary">Ingeniería</a>
          <ChevronRight className="size-3" />
          <a href="#" className="transition-colors hover:text-primary">Estructural</a>
          <ChevronRight className="size-3" />
          <span className="text-foreground/70">Diseño Sísmico</span>
        </nav>

        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 text-xs font-medium tracking-wide text-primary">
          <span className="size-1.5 rounded-full bg-primary" />
          {course.badge}
        </div>

        <h1 className="max-w-2xl font-display text-3xl font-bold leading-tight tracking-tight text-balance md:text-5xl">
          {course.title}
        </h1>

        <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg text-pretty">
          {course.subtitle}
        </p>

        <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-primary">{course.rating}</span>
            <Stars rating={course.rating} />
            <span className="text-muted-foreground">
              ({course.ratingCount.toLocaleString('es')} calificaciones)
            </span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="size-4 text-primary/70" />
            {course.students.toLocaleString('es')} estudiantes
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
          <span className="flex items-center gap-2">
            <BarChart3 className="size-4 text-primary/70" /> {course.level}
          </span>
          <span className="flex items-center gap-2">
            <Clock className="size-4 text-primary/70" /> {course.totalHours} horas de contenido
          </span>
          <span className="flex items-center gap-2">
            <Globe className="size-4 text-primary/70" /> {course.language}
          </span>
          <span>Actualizado {course.lastUpdated}</span>
        </div>
      </div>
    </section>
  )
}
