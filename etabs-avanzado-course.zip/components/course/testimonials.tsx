import { Star, Quote } from 'lucide-react'
import { testimonials, course } from '@/lib/course-data'

export function Testimonials() {
  return (
    <section>
      <div className="mb-6 flex flex-wrap items-center gap-x-3 gap-y-1">
        <h2 className="font-display text-xl font-semibold tracking-tight md:text-2xl">
          Lo que dicen los estudiantes
        </h2>
        <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <Star className="size-4 text-primary" fill="currentColor" />
          <span className="font-semibold text-primary">{course.rating}</span>
          calificación del curso · {course.ratingCount.toLocaleString('es')} reseñas
        </span>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {testimonials.map((t) => (
          <figure
            key={t.name}
            className="relative flex flex-col rounded-xl border border-border bg-card p-6"
          >
            <Quote className="absolute right-5 top-5 size-8 text-primary/15" fill="currentColor" />
            <div className="flex items-center gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className="size-4 text-primary"
                  fill={i < t.rating ? 'currentColor' : 'none'}
                  strokeWidth={1.5}
                />
              ))}
            </div>
            <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-muted-foreground text-pretty">
              &ldquo;{t.text}&rdquo;
            </blockquote>
            <figcaption className="mt-5 flex items-center gap-3">
              <span className="flex size-10 items-center justify-center rounded-full bg-primary/15 font-display text-sm font-semibold text-primary">
                {t.name
                  .split(' ')
                  .map((n) => n[0])
                  .slice(0, 2)
                  .join('')}
              </span>
              <span>
                <span className="block text-sm font-medium text-foreground">{t.name}</span>
                <span className="block text-xs text-muted-foreground">{t.role}</span>
              </span>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  )
}
