'use client'

import {
  Play,
  Infinity as InfinityIcon,
  Smartphone,
  Award,
  FileText,
  Download,
  Heart,
  ShieldCheck,
  Clock,
} from 'lucide-react'
import { useState } from 'react'
import Image from 'next/image'
import { course } from '@/lib/course-data'

const includes = [
  { icon: Clock, label: `${course.totalHours} horas de video bajo demanda` },
  { icon: FileText, label: '32 recursos descargables y plantillas' },
  { icon: Download, label: 'Modelos de ETABS listos para usar' },
  { icon: Smartphone, label: 'Acceso en móvil, tablet y escritorio' },
  { icon: InfinityIcon, label: 'Acceso de por vida' },
  { icon: Award, label: 'Certificado de finalización' },
]

export function PurchasePanel() {
  const [wished, setWished] = useState(false)
  const discount = Math.round(
    (1 - course.price / course.originalPrice) * 100,
  )

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card shadow-2xl shadow-black/40">
      {/* preview */}
      <button className="group relative block aspect-video w-full overflow-hidden">
        <Image
          src="/course-preview.png"
          alt="Vista previa del modelo estructural del curso en ETABS"
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          sizes="380px"
        />
        <span className="absolute inset-0 bg-background/40 transition-colors group-hover:bg-background/20" />
        <span className="absolute inset-0 flex items-center justify-center">
          <span className="flex size-16 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-transform group-hover:scale-110">
            <Play className="ml-1 size-7" fill="currentColor" />
          </span>
        </span>
        <span className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-background/80 px-3 py-1 text-xs font-medium text-foreground backdrop-blur-sm">
          Ver vista previa gratuita
        </span>
      </button>

      <div className="p-6">
        <div className="flex items-end gap-3">
          <span className="font-display text-3xl font-bold text-foreground">
            ${course.price}
          </span>
          <span className="pb-1 text-base text-muted-foreground line-through">
            ${course.originalPrice}
          </span>
          <span className="mb-1 rounded-md bg-primary/15 px-2 py-0.5 text-xs font-semibold text-primary">
            -{discount}%
          </span>
        </div>

        <p className="mt-2 flex items-center gap-1.5 text-sm font-medium text-primary">
          <Clock className="size-4" />
          ¡La oferta termina en {course.discountEndsIn}!
        </p>

        <div className="mt-5 flex flex-col gap-3">
          <button className="w-full rounded-lg bg-primary py-3 font-display text-base font-semibold text-primary-foreground transition-all hover:brightness-110 active:scale-[0.99]">
            Comprar ahora
          </button>
          <div className="flex gap-3">
            <button className="flex-1 rounded-lg border border-border bg-secondary py-3 text-sm font-medium text-foreground transition-colors hover:border-primary/50 hover:bg-accent">
              Añadir al carrito
            </button>
            <button
              onClick={() => setWished((w) => !w)}
              aria-pressed={wished}
              aria-label="Guardar en favoritos"
              className="flex size-12 shrink-0 items-center justify-center rounded-lg border border-border bg-secondary text-foreground transition-colors hover:border-primary/50 hover:bg-accent"
            >
              <Heart
                className="size-5 transition-colors"
                fill={wished ? 'var(--primary)' : 'none'}
                stroke={wished ? 'var(--primary)' : 'currentColor'}
              />
            </button>
          </div>
        </div>

        <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
          <ShieldCheck className="size-4 text-primary/70" />
          Garantía de reembolso de 30 días
        </p>

        <div className="mt-6 border-t border-border/60 pt-5">
          <h3 className="font-display text-sm font-semibold text-foreground">
            Este curso incluye
          </h3>
          <ul className="mt-3 flex flex-col gap-3">
            {includes.map(({ icon: Icon, label }) => (
              <li key={label} className="flex items-start gap-3 text-sm text-muted-foreground">
                <Icon className="mt-0.5 size-4 shrink-0 text-primary/80" />
                <span>{label}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-5 flex items-center justify-center gap-4 border-t border-border/60 pt-4 text-xs font-medium text-muted-foreground">
          <button className="underline-offset-4 transition-colors hover:text-primary hover:underline">
            Compartir
          </button>
          <span className="text-border">|</span>
          <button className="underline-offset-4 transition-colors hover:text-primary hover:underline">
            Regalar este curso
          </button>
        </div>
      </div>
    </div>
  )
}
