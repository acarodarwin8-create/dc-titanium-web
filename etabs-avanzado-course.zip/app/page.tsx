import { TopNav } from '@/components/course/top-nav'
import { Hero } from '@/components/course/hero'
import { PurchasePanel } from '@/components/course/purchase-panel'
import { WhatYouLearn } from '@/components/course/what-you-learn'
import { Curriculum } from '@/components/course/curriculum'
import { Requirements } from '@/components/course/requirements'
import { InstructorSection } from '@/components/course/instructor-section'
import { Testimonials } from '@/components/course/testimonials'
import { MobilePurchaseBar } from '@/components/course/mobile-purchase-bar'

export default function CoursePage() {
  return (
    <div className="min-h-screen bg-background">
      <TopNav />
      <Hero />

      <main className="relative mx-auto max-w-7xl px-4 pb-24 md:px-8 lg:pb-16">
        <div className="lg:grid lg:grid-cols-3 lg:gap-10">
          {/* Left: content */}
          <div className="flex flex-col gap-12 py-10 lg:col-span-2">
            <WhatYouLearn />
            <Curriculum />
            <Requirements />
            <InstructorSection />
            <Testimonials />
          </div>

          {/* Right: sticky purchase panel */}
          <aside className="hidden lg:col-span-1 lg:block">
            <div className="sticky top-24 -mt-56 pb-10">
              <PurchasePanel />
            </div>
          </aside>
        </div>
      </main>

      <MobilePurchaseBar />

      <footer className="border-t border-border/60 py-10">
        <div className="mx-auto flex max-w-7xl flex-col items-center gap-3 px-4 text-center md:px-8">
          <span className="font-display text-lg font-semibold tracking-tight">
            Estructura<span className="text-primary">Pro</span>
          </span>
          <p className="text-xs text-muted-foreground">
            Formación avanzada en ingeniería estructural y diseño sísmico.
          </p>
          <p className="text-xs text-muted-foreground/70">
            © 2026 EstructuraPro. Todos los derechos reservados.
          </p>
        </div>
      </footer>
    </div>
  )
}
